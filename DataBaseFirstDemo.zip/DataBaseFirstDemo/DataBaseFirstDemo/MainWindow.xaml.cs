﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace DataBaseFirstDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //1. Obtain data source
            var ContextObj = new DXCDatabaseEntities();


            //2. Createe query
            var DepartmentQueryObj = from dept in ContextObj.Departments
                                     select dept;

            //3. Execute
            dataGrid.ItemsSource = DepartmentQueryObj.ToList();


            //Query all employees
            var EmployeeQueryObj = from emp in ContextObj.Employees
                                   select emp;

            dataGrid1.ItemsSource = EmployeeQueryObj.ToList();
        }
    }
}
